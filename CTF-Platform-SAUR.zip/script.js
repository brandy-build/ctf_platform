// Challenge Data
const challenges = {
    'Web Exploitation': {
        icon: '🌐',
        color: '#00d4ff',
        challenges: [
            {
                id: 'web_easy',
                title: 'SQL Injection 101',
                difficulty: 'easy',
                points: 100,
                description: 'Find the SQL injection vulnerability in the login form and retrieve the admin flag. Hint: Try adding a single quote (\'1\'=\'1) in the username field.',
                flag: 'SAUR{sql_injection_bypassed}',
                category: 'Web Exploitation'
            },
            {
                id: 'web_hard',
                title: 'XSS & CSRF Exploitation',
                difficulty: 'hard',
                points: 200,
                description: 'Exploit both XSS and CSRF vulnerabilities in the commented form. You need to craft a malicious payload that steals session cookies and perform unauthorized actions.',
                flag: 'SAUR{xss_csrf_master}',
                category: 'Web Exploitation'
            }
        ]
    },
    'Cryptography': {
        icon: '🔐',
        color: '#ff6b00',
        challenges: [
            {
                id: 'crypto_easy',
                title: 'Caesar Cipher Decryption',
                difficulty: 'easy',
                points: 100,
                description: 'Decrypt the following message using Caesar cipher: "Wkh txlfn eurzq ira mxpsv ryhu wkh odcb grj". Find the correct shift value and submit the decrypted message as the flag.',
                flag: 'SAUR{the_quick_brown_fox}',
                category: 'Cryptography'
            },
            {
                id: 'crypto_hard',
                title: 'RSA Private Key Recovery',
                difficulty: 'hard',
                points: 200,
                description: 'Given RSA public parameters, determine the private key. You have: n=6537424611447, e=65537. Factor the modulus to find p and q, then calculate d.',
                flag: 'SAUR{rsa_private_key_exposed}',
                category: 'Cryptography'
            }
        ]
    },
    'Binary': {
        icon: '⚙️',
        color: '#00ff41',
        challenges: [
            {
                id: 'binary_easy',
                title: 'Buffer Overflow Basics',
                difficulty: 'easy',
                points: 100,
                description: 'Analyze a vulnerable C program with a fixed-size buffer. Craft an input that overflows the buffer and overwrites the return address to jump to a hidden function that prints the flag.',
                flag: 'SAUR{buffer_overflow_success}',
                category: 'Binary'
            },
            {
                id: 'binary_hard',
                title: 'ROP Chain Exploitation',
                difficulty: 'hard',
                points: 200,
                description: 'Perform a Return-Oriented Programming (ROP) attack on a binary with ASLR enabled. Construct a ROP chain to bypass protections and execute system calls to read the flag file.',
                flag: 'SAUR{rop_chain_master}',
                category: 'Binary'
            }
        ]
    },
    'Forensics': {
        icon: '🔍',
        color: '#ff1744',
        challenges: [
            {
                id: 'forensics_easy',
                title: 'Metadata Extraction',
                difficulty: 'easy',
                points: 100,
                description: 'Analyze a JPEG image and extract hidden metadata. Use tools like exiftool to find embedded information. The GPS coordinates and timestamp contain clues to the flag.',
                flag: 'SAUR{metadata_revealed}',
                category: 'Forensics'
            },
            {
                id: 'forensics_hard',
                title: 'Disk Image Recovery',
                difficulty: 'hard',
                points: 200,
                description: 'Recover deleted files from a disk image using forensic tools. Mount the image and search for unallocated space containing fragments of the flag file. Reconstruct the deleted data.',
                flag: 'SAUR{deleted_files_recovered}',
                category: 'Forensics'
            }
        ]
    },
    'OSINT': {
        icon: '🕵️',
        color: '#ff1493',
        challenges: [
            {
                id: 'osint_easy',
                title: 'WHOIS & DNS Reconnaissance',
                difficulty: 'easy',
                points: 100,
                description: 'Perform WHOIS and DNS lookups on a domain. Find hidden subdomains, MX records, and administrative contact information. The flag is hidden in the domain registrant\'s contact details.',
                flag: 'SAUR{osint_domain_enum}',
                category: 'OSINT'
            },
            {
                id: 'osint_hard',
                title: 'Social Engineering & Open Source Intelligence',
                difficulty: 'hard',
                points: 200,
                description: 'Gather intelligence from public sources: social media profiles, GitHub repositories, LinkedIn connections, and company websites. Piece together sensitive information to find credentials or hidden API endpoints.',
                flag: 'SAUR{osint_social_engineer}',
                category: 'OSINT'
            }
        ]
    }
};

// State Management
let completedChallenges = new Set();
let totalScore = 0;
let currentChallenge = null;

// Initialize the platform
document.addEventListener('DOMContentLoaded', function() {
    renderCategories();
    renderProgressBars();
    loadFromLocalStorage();
    updateClock();
    setInterval(updateClock, 1000);
});

// Live Clock
function updateClock() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    document.getElementById('liveTime').textContent = `${hours}:${minutes}:${seconds}`;
}

// Render Category Cards
function renderCategories() {
    const grid = document.getElementById('categoriesGrid');
    grid.innerHTML = '';

    Object.entries(challenges).forEach(([categoryName, categoryData]) => {
        const card = document.createElement('div');
        card.className = 'category-card';
        
        const completedCount = categoryData.challenges.filter(c => completedChallenges.has(c.id)).length;
        
        card.innerHTML = `
            <div class="category-header">
                <div class="category-icon">${categoryData.icon}</div>
                <div class="category-name">${categoryName}</div>
            </div>
            <div class="category-challenges">
                ${categoryData.challenges.map(challenge => `
                    <div class="challenge-item ${completedChallenges.has(challenge.id) ? 'completed' : ''}" 
                         onclick="openChallenge('${challenge.id}', '${categoryName}')">
                        <div class="challenge-title">
                            ${completedChallenges.has(challenge.id) ? '✓ ' : ''}${challenge.title}
                        </div>
                        <div class="challenge-meta">
                            <span class="difficulty ${challenge.difficulty}">${challenge.difficulty}</span>
                            <span class="points">+${challenge.points} pts</span>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
        
        grid.appendChild(card);
    });
}

// Render Progress Bars
function renderProgressBars() {
    const container = document.getElementById('progressContainer');
    container.innerHTML = '';

    Object.entries(challenges).forEach(([categoryName, categoryData]) => {
        const completed = categoryData.challenges.filter(c => completedChallenges.has(c.id)).length;
        const total = categoryData.challenges.length;
        const percentage = (completed / total) * 100;

        const progressDiv = document.createElement('div');
        progressDiv.className = 'category-progress';
        progressDiv.innerHTML = `
            <div class="progress-title">${categoryName}</div>
            <div class="progress-bar-container">
                <div class="progress-bar-fill" style="width: ${percentage}%">
                    ${percentage > 0 ? `${completed}/${total}` : ''}
                </div>
            </div>
            <div class="progress-percentage">${Math.round(percentage)}% Complete</div>
        `;
        
        container.appendChild(progressDiv);
    });
}

// Update Stats
function updateStats() {
    const flagCount = completedChallenges.size;
    document.getElementById('flagCount').textContent = `${flagCount}/10`;
    document.getElementById('scoreCount').textContent = totalScore;
}

// Open Challenge Modal
function openChallenge(challengeId, categoryName) {
    const categoryData = challenges[categoryName];
    const challenge = categoryData.challenges.find(c => c.id === challengeId);
    
    if (!challenge) return;

    currentChallenge = challenge;
    
    document.getElementById('modalTitle').textContent = challenge.title;
    document.getElementById('difficultyBadge').textContent = challenge.difficulty.toUpperCase();
    document.getElementById('difficultyBadge').className = `difficulty-badge ${challenge.difficulty}`;
    document.getElementById('modalDescription').textContent = challenge.description;
    document.getElementById('pointsValue').textContent = challenge.points;
    document.getElementById('flagInput').value = '';
    document.getElementById('feedback').innerHTML = '';
    
    const modal = document.getElementById('challengeModal');
    modal.classList.add('active');
}

// Close Modal
function closeModal() {
    const modal = document.getElementById('challengeModal');
    modal.classList.remove('active');
    currentChallenge = null;
}

// Submit Flag
function submitFlag() {
    if (!currentChallenge) return;

    const userInput = document.getElementById('flagInput').value.trim();
    const feedback = document.getElementById('feedback');

    if (!userInput) {
        feedback.textContent = 'Please enter a flag';
        feedback.className = 'feedback error';
        return;
    }

    // Case-insensitive comparison and flexible matching
    const normalizedInput = userInput.toLowerCase();
    const normalizedFlag = currentChallenge.flag.toLowerCase();

    if (normalizedInput === normalizedFlag) {
        // Correct flag
        if (!completedChallenges.has(currentChallenge.id)) {
            completedChallenges.add(currentChallenge.id);
            totalScore += currentChallenge.points;
            
            saveToLocalStorage();
            updateStats();
            renderCategories();
            renderProgressBars();
            
            feedback.textContent = `🎉 Correct! You earned ${currentChallenge.points} points!`;
            feedback.className = 'feedback success';
            
            setTimeout(() => {
                closeModal();
            }, 2000);
        } else {
            feedback.textContent = '✓ You already captured this flag!';
            feedback.className = 'feedback success';
        }
    } else {
        // Incorrect flag
        feedback.textContent = '✗ Incorrect flag. Try again!';
        feedback.className = 'feedback error';
    }
}

// Allow Enter key to submit
document.addEventListener('keypress', function(e) {
    const modal = document.getElementById('challengeModal');
    if (modal.classList.contains('active') && e.key === 'Enter') {
        submitFlag();
    }
});

// Close modal on outside click
document.getElementById('challengeModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeModal();
    }
});

// LocalStorage Management
function saveToLocalStorage() {
    const data = {
        completedChallenges: Array.from(completedChallenges),
        totalScore: totalScore
    };
    localStorage.setItem('ctfProgress', JSON.stringify(data));
}

function loadFromLocalStorage() {
    const data = localStorage.getItem('ctfProgress');
    if (data) {
        const parsed = JSON.parse(data);
        completedChallenges = new Set(parsed.completedChallenges);
        totalScore = parsed.totalScore;
        updateStats();
        renderCategories();
        renderProgressBars();
    }
}

// Add hint functionality
function getHint(challengeId) {
    const hints = {
        'web_easy': 'Try: admin\' OR \'1\'=\'1',
        'web_hard': 'Combine XSS payload with CSRF token manipulation',
        'crypto_easy': 'ROT13 or shift by 3',
        'crypto_hard': 'Use online RSA factorization tools or write a factorization script',
        'binary_easy': 'Pattern: AAAA...AAAA + return address',
        'binary_hard': 'Find gadgets in libc: pop rdi; ret; syscall; etc.',
        'forensics_easy': 'Use: exiftool <image_name>',
        'forensics_hard': 'Use photorec or recovery tools on the disk image',
        'osint_easy': 'Check whois and nslookup results carefully',
        'osint_hard': 'Search GitHub, LinkedIn, and public records'
    };
    
    return hints[challengeId] || 'No hint available';
}

// Particle animation for background
function createParticles() {
    const container = document.querySelector('.particle-background');
    for (let i = 0; i < 20; i++) {
        const particle = document.createElement('div');
        particle.style.position = 'absolute';
        particle.style.width = Math.random() * 3 + 1 + 'px';
        particle.style.height = particle.style.width;
        particle.style.backgroundColor = 'rgba(0, 212, 255, 0.5)';
        particle.style.borderRadius = '50%';
        particle.style.left = Math.random() * 100 + '%';
        particle.style.top = Math.random() * 100 + '%';
        particle.style.animation = `float ${Math.random() * 10 + 5}s infinite`;
        container.appendChild(particle);
    }
}

// Animation keyframes for particles
const style = document.createElement('style');
style.textContent = `
    @keyframes float {
        0%, 100% {
            transform: translateY(0px) translateX(0px);
            opacity: 0.5;
        }
        50% {
            transform: translateY(-30px) translateX(10px);
            opacity: 1;
        }
    }
`;
document.head.appendChild(style);

// Create particles on load
window.addEventListener('load', createParticles);
